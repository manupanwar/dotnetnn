﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using CAPGEMINI.GuestPhoneBook.Entities;
using CAPGEMINI.GuestPhoneBook.Exceptions;
using CAPGEMINI.GuestPhoneBook.BusinessLayer;

namespace CAPGEMINI.GuestPhoneBook.WPFApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetAllGuest();
        }

        private void GetAllGuest()
        {
            try
            {
                List<Guest> guestList = GuestBL.GetAllGuestBL();
                dgPhonebook.ItemsSource = guestList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Guest newGuest = new Guest();
                newGuest.GuestName = txtName.Text;
                newGuest.GuestContactNumber = txtContact.Text;

                bool status = GuestBL.AddGuestBL(newGuest);

                if (status)
                {
                    MessageBox.Show("Guest Added");
                    txtName.Text = "";
                    txtContact.Text = "";
                    GetAllGuest();
                }
                else
                {
                    MessageBox.Show("Guest Not added");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text);
                Guest searchGuest =GuestBL.SearchGuestBL(id);

                if (searchGuest != null)
                {
                    txtnewName.Text = searchGuest.GuestName;
                    txtnewContact.Text = searchGuest.GuestContactNumber.ToString();
                }
                else
                {
                    MessageBox.Show("No Guest Deatails Available");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Guest updateGuest = new Guest();
                updateGuest.GuestID= Convert.ToInt32(txtId.Text);
                updateGuest.GuestName= txtnewName.Text;
                updateGuest.GuestContactNumber=txtnewContact.Text;

                bool status = GuestBL.UpdateGuestBL(updateGuest);
                if(status)
                {
                    MessageBox.Show("Guest Deatils Updated");
                    txtnewContact.Text ="";
                    txtnewName.Text="";
                    txtId.Text ="";
                    GetAllGuest();
                }
                else
                {
                    MessageBox.Show("Guest Details not Updated");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text);

                MessageBoxResult dres = MessageBox.Show("Do you want to delete the record?","Confirmation",MessageBoxButton.YesNo);

                if (dres==MessageBoxResult.Yes)
                {
                    bool status = GuestBL.DeleteGuestBL(id);

                    if (status)
                    {
                        MessageBox.Show("Guest Details deleted");
                        txtnewContact.Text = "";
                        txtnewName.Text = "";
                        txtId.Text = "";
                        GetAllGuest();
                    }
                    else
                    {
                        MessageBox.Show("Guest Details not deleted");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
