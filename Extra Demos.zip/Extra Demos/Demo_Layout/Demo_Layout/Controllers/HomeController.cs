﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Demo_Layout.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult IndexII()
        {
            return View();
        }

        
        public ActionResult Contact()
        {
            return View("Contact", "~/Views/Shared/_LayoutPage3.cshtml");
        }

    }
}