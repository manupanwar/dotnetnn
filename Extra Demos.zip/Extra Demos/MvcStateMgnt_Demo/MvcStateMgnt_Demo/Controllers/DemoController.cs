﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcStateMgnt_Demo.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult Index()
        {            
            return View();
        }

        // POST: Demo
        [HttpPost]
        public ActionResult Index(string id)
        {
            Session["userName"] = id;
            ViewBag.Summary = "ASP.NET MVC there are three ways - ViewData, ViewBag and TempData to pass data from controller to view and in next request. Like WebForm, you can also use Session to persist data during a user session. Now question is that when to use ViewData, VieBag, TempData and Session. Each of them has its own importance. We will try to explain the differences among these four.";
            return View();
        }

        // GET: Demo/UseViewData
        public ActionResult UseViewData()
        {
            List<string> points = new List<string> 
            {
                "ViewData is a dictionary object that is derived from ViewDataDictionary class.",
                "ViewData is a property of ControllerBase class.",
                "ViewData is used to pass data from controller to corresponding view.",
                "It’s life lies only during the current request.",
                "If redirection occurs then it’s value becomes null.",
                "It’s required typecasting for getting data and check for null values to avoid error."
            };
            ViewBag.Points = points;

            return View();
        }

        // GET: Demo/UseViewBag
        public ActionResult UseViewBag()
        {
            List<string> points = new List<string> 
            {
                "ViewBag is a dynamic property that takes advantage of the new dynamic features in C# 4.0.",
                "Basically it is a wrapper around the ViewData and also used to pass data from controller to corresponding view.",
                "ViewBag is a property of ControllerBase class.",
                "It’s life also lies only during the current request.",
                "If redirection occurs then it’s value becomes null.",
                "It doesn’t required typecasting for getting data."
            };
            ViewBag.Points = points;

            return View();
        }

        // GET: Demo/UseTempData
        public ActionResult UseTempData()
        {
            List<string> points = new List<string> 
            {
                "TempData is a dictionary object that is derived from TempDataDictionary class and stored in short lives session.",
                "TempData is a property of ControllerBase class.",
                "TempData is used to pass data from current request to subsequent request (means redirecting from one page to another).",
                "It’s life is very short and lies only till the target view is fully loaded.",
                "It’s required typecasting for getting data and check for null values to avoid error.",
                "It is used to store only one time messages like error messages, validation messages."
            };

            TempData["Points"] = points;

            return RedirectToAction("SubsequentRequest");
        }

        public ActionResult SubsequentRequest()
        {
            return View();
        }
    }
}