﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Mvc_ActionFilters_Demo.Controllers
{
    public class FiltersController : Controller
    {        
        public ActionResult Index()
        {
            return View();
        }


        [OutputCache(Duration = 10)]
        public ActionResult OutputCache()
        {
            ViewBag.DateTime = DateTime.Now.ToLongTimeString();
            return View();
        }


        [Authorize]
        public ActionResult OnlyForAuthorisedUsers()
        {            
            return View();
        }
       

        public ActionResult ValidateInputFilter()
        {
            return View();
        }

            [ValidateInput(false)]
        [HttpPost]        
        public ActionResult ValidateInputFilter(string txtData)
        {
            ViewBag.Input = txtData;
            return View();
        }

        public ActionResult ForgeryTest()
        {
            return View();
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ForgeryTest(string txtData)
        {
            ViewBag.Input = txtData;
            return View();
        }

        [HandleError]
        public ActionResult ExceptionFilterTest()
        {
            //Here is some code
            throw new Exception();
            return View();
        }
    }
}
