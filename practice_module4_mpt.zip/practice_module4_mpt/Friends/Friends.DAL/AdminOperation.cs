﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Friends.Entity;
using Friends.Exception;
using System.Data.SqlClient;

namespace Friends.DAL
{
    public class AdminOperation
    {
        public static AdminFaculty Adminlogin(AdminFaculty fac)
        {
            
              AdminFaculty validFac = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_ValidateLogin_133875";
                cmd.Parameters.AddWithValue("@FacID", fac.FacultyID);
                cmd.Parameters.AddWithValue("@Pwd", fac.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    validFac = new AdminFaculty();
                    dr.Read();
                    validFac.FacultyID = (int)dr["FacultyID"];
                    validFac.Username = dr["Username"].ToString();
                    validFac.Password = dr["Password"].ToString();
                   
                }

                else
                    throw new AdminException("UserID/Password is wrong");
            }
            catch(AdminException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validFac;
        }
        }
    }

