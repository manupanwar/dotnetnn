﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Friends.DAL
{
    public class FacultyOperation
    {
        public static int InsertFaculty(Entity.Faculty1 fac)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertFaculty_133875";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Fac_Name", fac.FacName);
                cmd.Parameters.AddWithValue("@Gender", fac.Gender);
                cmd.Parameters.AddWithValue("@Type", fac.Type);
                cmd.Parameters.AddWithValue("@LOT", fac.LOT);
                cmd.Parameters.AddWithValue("@Email", fac.EmailId);
                cmd.Parameters.AddWithValue("@Mobile", fac.Mobile);
                cmd.Parameters.AddWithValue("@Location", fac.Location);
                cmd.Parameters.AddWithValue("@Skills", fac.CertifiedSkills);
                cmd.Parameters.AddWithValue("@DOJ", fac.DOJ);


                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        }
    }

