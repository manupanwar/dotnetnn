﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Friends.Entity
{
    public class Faculty1
    {
        //Get or set Faculty Name
        public string FacName { get; set; }

        //Get or set Gender
        public string Gender { get; set; }

        //Get or set Faculty Type
        public string Type { get; set; }

        //Get or set LOT
        public string LOT { get; set; }

        //Get or set email
        public string EmailId { get; set; }

        //Get or set mobile
        public string Mobile { get; set; }

        //Get or set Location
        public string Location { get; set; }

        //Get or Set Student Date of Joining
        public DateTime DOJ { get; set; }

        //Get or set Certified Skills
        public string CertifiedSkills { get; set; }
    }
}
