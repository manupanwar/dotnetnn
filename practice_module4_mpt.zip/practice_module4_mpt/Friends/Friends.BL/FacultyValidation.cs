﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Friends.DAL;
using Friends.Entity;
using Friends.Exception;

namespace Friends.BL
{
    public class FacultyValidation
    {
        public static int InsertFaculty(Entity.Faculty1 fac)
        {
           int recordsAffected = 0;

            try
            {
                recordsAffected = FacultyOperation.InsertFaculty(fac);

            }
            catch (FacultyException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
      }
    }

