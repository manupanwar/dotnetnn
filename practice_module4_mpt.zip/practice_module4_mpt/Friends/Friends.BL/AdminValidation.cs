﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Friends.Entity;
using Friends.Exception;
using Friends.DAL;

namespace Friends.BL
{
    public class AdminValidation
    {
        public static AdminFaculty login(AdminFaculty fac)
        {
           AdminFaculty validFac = null;

            try 
            {
                validFac= AdminOperation.Adminlogin(fac);
            }
            catch (AdminException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validFac;
        }

      

       
    }
}
