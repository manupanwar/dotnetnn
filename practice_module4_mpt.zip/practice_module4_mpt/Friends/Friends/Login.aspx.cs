﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Friends.BL;
using Friends.Entity;
using Friends.Exception;

namespace Friends
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                AdminFaculty fac = new AdminFaculty();
                fac.FacultyID = Convert.ToInt32(txtUserid.Text);
                fac.Password = txtPassword.Text;

                AdminFaculty validFac = AdminValidation.login(fac);

                if (validFac != null)
                {
                    Session["user"] = validFac.FacultyID.ToString() + " " + validFac.Username;
                    Response.Redirect("FacultyRegistration.aspx");
                }
                else
                {
                    throw new AdminException("UserID/Password is wrong");
                }
            }
            catch (AdminException ex)
            {
                lblError.Visible = true;
                lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}