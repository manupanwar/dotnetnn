﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Friends.Exception;
using Friends.Entity;
using Friends.BL;

namespace Friends
{
    public partial class FacultyRegistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] == null)
            //{
            //    Response.Redirect("Login.aspx");
            //}

            Master.LogoutVisible = true;
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
             try 
            {
                Faculty1 fac = new Faculty1();


                fac.FacName = txtFacName.Text;
                fac.Gender = rblistGender.Text;
                fac.Type = cmbFacType.Text;
                fac.LOT = cmbLOT.Text;
                fac.EmailId = txtemail.Text;
                fac.Mobile = txtFacMobile.Text;
                fac.Location = cmbLocation.Text;
                fac.CertifiedSkills = txtFacSkills.Text;
                fac.DOJ = Convert.ToDateTime(txtDOJ.Text);


                int rowsAffected = FacultyValidation.InsertFaculty(fac);

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Faculty Data inserted Successfully');</script>");
                    //Response.Redirect("Home.aspx");
                }
                else
                    throw new FacultyException("Faculty Record not Inserted");
            }
            catch (FacultyException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
         }
     }
}
    
