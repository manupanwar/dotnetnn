﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Lab2.Models;

namespace Lab2.Controllers
{
    public class EmployeeController : ApiController
    {
        private EmployeeContext db = new EmployeeContext();

        // GET api/Employee
        List<Employee> Employeelist = new List<Employee>()
    {
        new Employee {EmployeeID=848802,FirstName="Snehal",LastName="Sane",Grade="A",DOB="05/05/1995",EmailID="snehalsane5@gmail.com",Contact="9029179879"},
        new Employee {EmployeeID=848801,FirstName="Sachin",LastName="Nikam",Grade="A+",DOB="07/09/199",EmailID="sachinn246@gmail.com",Contact="9930025281"},
        new Employee {EmployeeID=848851,FirstName="Shruti",LastName="Rao",Grade="B",DOB="08/10/199",EmailID="shrurao@yahoo.co.in",Contact="9869717369"},
        new Employee {EmployeeID=848865,FirstName="Shrii",LastName="Shinde",Grade="A",DOB="12/12/1989",EmailID="srii@msn3.com",Contact="9967670940"}
    };

        public IEnumerable<Employee> GetEmployee()
        {
            return Employeelist;
        }

        // GET api/Employee/5
        [ResponseType(typeof(Employee))]
        public IHttpActionResult GetEmployee(int id)
        {
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }

            return Ok(employee);
        }

        // PUT api/Employee/5
        public IHttpActionResult PutEmployee(int id, Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != employee.EmployeeID)
            {
                return BadRequest();
            }

            db.Entry(employee).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EmployeeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST api/Employee
        [ResponseType(typeof(Employee))]
        public IHttpActionResult PostEmployee(Employee employee)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.Employees.Add(employee);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = employee.EmployeeID }, employee);
        }

        // DELETE api/Employee/5
        [ResponseType(typeof(Employee))]
        public IHttpActionResult DeleteEmployee(int id)
        {
            Employee employee = db.Employees.Find(id);
            if (employee == null)
            {
                return NotFound();
            }

            db.Employees.Remove(employee);
            db.SaveChanges();

            return Ok(employee);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool EmployeeExists(int id)
        {
            return db.Employees.Count(e => e.EmployeeID == id) > 0;
        }
    }
}