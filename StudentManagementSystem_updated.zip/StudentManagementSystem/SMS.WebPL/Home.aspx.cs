﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.WebPL
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
                Response.Redirect("Login.aspx");
            Master.LogoutVisible = true;
            Master.MenuVisible = true;
            lblWelcome.Text = "Welcome " + Session["user"];

            try 
            {
                List<Student> studentList = null;
                studentList = StudentValidation.RetrieveStudent();
                if (studentList.Count > 0)
                {
                    gvStudent.DataSource = studentList;
                    gvStudent.DataBind();
                }
                else
                {
                    throw new StudentException("Student Data not Available");
                }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}