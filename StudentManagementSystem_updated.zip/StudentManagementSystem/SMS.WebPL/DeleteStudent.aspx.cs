﻿using SMS.BL;
using SMS.Entity;
using SMS.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.WebPL
{
    public partial class DeleteStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
                Response.Redirect("Login.aspx");

            Master.LogoutVisible = true;
            Master.MenuVisible = true;

            if (!Page.IsPostBack)
            {
                try
                {
                    Dictionary<int, string> dictionaryStud = null;

                    dictionaryStud = StudentValidation.RetrieveStudentName();

                    if (dictionaryStud.Count > 0)
                    {
                        foreach (var key in dictionaryStud.Keys)
                        {
                            ListItem lst = new ListItem();
                            lst.Value = key.ToString();
                            lst.Text = dictionaryStud[key];

                            ddlStudent.Items.Add(lst);
                        }
                    }
                    else
                        throw new StudentException("Student Data not Available");
                }
                catch (StudentException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                int studCode = Convert.ToInt32(txtStudCode.Text);

                int rowsAffected = StudentValidation.DeleteStudent(studCode);

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Student Data updated Successfully');</script>");
                    Response.Redirect("Home.aspx");
                }
                else
                    throw new StudentException("Student Record not Updated");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = StudentValidation.SearchStudent(Convert.ToInt32(ddlStudent.SelectedItem.Value));

                txtStudCode.Text = stud.StudCode.ToString();
                txtStudName.Text = stud.StudName;
                txtDeptCode.Text = stud.DeptCode.ToString();
                txtStudDob.Text = stud.DOB.ToString();
                txtAddress.Text = stud.Address;
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

       
    }
}