﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.WebPL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try 
            {
                AdminEmployee emp = new AdminEmployee();
                emp.EmployeeID = Convert.ToInt32(txtEmployeeID.Text);
                emp.Password = txtPassword.Text;

                AdminEmployee validEmp = AdminEmployeeValidation.ValidateLogin(emp);

                if (validEmp != null)
                {
                    Session["user"] = validEmp.EmployeeID.ToString() + " " + validEmp.EmployeeName;
                    Response.Redirect("Home.aspx");
                }
                else
                {
                    throw new AdminEmployeeException("EmployeeID/Password is wrong");
                }
            }
            catch (AdminEmployeeException ex)
            {
                lblError.Visible = true;
                lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}