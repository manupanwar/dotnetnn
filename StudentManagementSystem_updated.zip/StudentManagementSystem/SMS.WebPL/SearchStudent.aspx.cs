﻿using SMS.BL;
using SMS.Entity;
using SMS.Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SMS.WebPL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["user"] == null)
                Response.Redirect("Login.aspx");

            Master.LogoutVisible = true;
            Master.MenuVisible = true;

            if (!Page.IsPostBack)
            {
                try
                {
                    List<int> deptnumber = null;

                    deptnumber = StudentValidation.RetrieveDepartmentName();

                    if (deptnumber.Count > 0)
                    {
                        foreach (var key in deptnumber)
                        {
                            ListItem lst = new ListItem();
                            lst.Value = key.ToString();
                            

                            ddlDeptcode.Items.Add(lst);
                        }
                    }
                    else
                        throw new StudentException("Student Data not Available");
                }
                catch (StudentException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
                catch (SystemException ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                int deptcode = Convert.ToInt32(ddlDeptcode.SelectedItem.Value);

               List<Student> stud = StudentValidation.SearchStudentbyDepartment(deptcode);
              
               if (stud.Count > 0)
               {
                   gvStudent.DataSource = stud;
                   gvStudent.DataBind();
               }
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}