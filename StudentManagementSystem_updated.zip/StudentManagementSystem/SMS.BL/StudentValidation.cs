﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;

namespace SMS.BL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date of Creation : 
    /// </summary>
    public class StudentValidation
    {
        public static bool ValildateStudent(Student stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try 
            {
                if (stud.StudCode <= 0)
                {
                    studValidated = false;
                    message.Append("Student code should be greater than 0\n");
                }

                if (stud.StudName == String.Empty)
                {
                    studValidated = false;
                    message.Append("Student name should be provided\n");
                }
                else if (!Regex.IsMatch(stud.StudName, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Student name should have alphabets only\n");
                }

                if (stud.DOB == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }

                if (studValidated == false)
                    throw new StudentException(message.ToString());
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try 
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperations.InsertStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = StudentOperations.UpdateStudent(stud);
                }
                else
                    throw new StudentException("Please provide valid Student Information");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = StudentOperations.DeleteStudent(studCode);
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Student SearchStudent(int studCode)
        {
            Student stud = null;

            try
            {
                stud = StudentOperations.SearchStudent(studCode);
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = null;

            try 
            {
                studList = StudentOperations.RetrieveStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }

        public static Dictionary<int, string> RetrieveStudentName()
        {
            Dictionary<int, string> dictionaryStudent = null;

            try 
            {
                dictionaryStudent = StudentOperations.RetrieveStudentName();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dictionaryStudent;
        }
        public static List<int> RetrieveDepartmentName()
        {
            List<int> deptnum = null;

            try
            {
                deptnum = StudentOperations.RetrieveDepartmentName();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return deptnum;
        }

        public static List<Student> SearchStudentbyDepartment(int deptCode)
        {
            List<Student> studentList = null;

            try 
            {
                studentList = StudentOperations.SearchStudentbyDepartment(deptCode);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studentList;
        }
    }
}
