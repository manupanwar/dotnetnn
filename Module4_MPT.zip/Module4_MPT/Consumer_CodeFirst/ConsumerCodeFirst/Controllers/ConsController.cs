﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ConsumerCodeFirst.Controllers
{
    public class ConsController : Controller
    {
        private ConDbContext db = new ConDbContext("Training");

        // GET: Cons
        public ActionResult Index()
        {
            var xyz = from con in db.Consumers.Where(c => c.BillerType == "Electricity" && c.ModeOfPayment == "CreditCard")
                      select new { con.CustomerId, con.MobileNumber };
            return View(xyz);
        }
    }
}