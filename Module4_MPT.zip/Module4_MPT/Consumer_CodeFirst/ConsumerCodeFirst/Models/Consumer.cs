﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ConsumerCodeFirst
{
    public class Consumer
    {

        public int ConsumerId { get; set; }

        public string BillerType { get; set; }

        public string CustomerId { get; set; }

        public string MobileNumber { get; set; }

        public int BillDate { get; set; }

        public DateTime PaymentDate { get; set; }

        public string ModeOfPayment { get; set; }

        public int BillAmount { get; set; }
    }
}