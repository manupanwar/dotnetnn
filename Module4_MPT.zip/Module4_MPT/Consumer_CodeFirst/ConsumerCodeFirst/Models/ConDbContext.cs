﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace ConsumerCodeFirst
{
    public class ConDbContext : DbContext
    {
        public ConDbContext(string conString) : base(conString)
        {

        }

        public virtual DbSet<Consumer> Consumers { get; set; }

        public ConDbContext()
        {

        }
    }
}