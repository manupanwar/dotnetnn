﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using Paisa.DataAccessLayer;

namespace Paisa.BuisnessLayer
{
   public class UserLoginBL
    {
        public static UserLogin ValidateLoginBL(UserLogin user)
        {
            UserLogin validuser = null;
           
            try
            {
                validuser = UserLoginDAL.ValidateLoginDAL(user);
            }
            catch (UserLoginException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validuser;
        }
    }
}
