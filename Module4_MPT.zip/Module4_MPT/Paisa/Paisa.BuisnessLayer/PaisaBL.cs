﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using Paisa.DataAccessLayer;

namespace Paisa.BuisnessLayer
{
    public class PaisaBL
    {
        public static int InsertConsumerBL(BillPayment bill)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = PaisaDAL.InsertConsumerDAL(bill);
                
              
            }
            catch (PaisaException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
