﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using System.Data.SqlClient;

namespace Paisa.DataAccessLayer
{
   public class UserLoginDAL
    {
        public static UserLogin ValidateLoginDAL(UserLogin emp)
        {
            UserLogin validUser = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_ValidateLoginUser";
                cmd.Parameters.AddWithValue("@ID", emp.UserID);
                cmd.Parameters.AddWithValue("@Pwd", emp.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    validUser = new UserLogin();
                    dr.Read();
                    validUser.UserName = dr["UserName"].ToString();
                }
                //else
                //    // throw new UserLoginException("UserID/Password is wrong");

                //    throw new UserLoginException("UserID/Password is incorrect");
            }
            catch (UserLoginException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validUser;
        }

        
    }
}
