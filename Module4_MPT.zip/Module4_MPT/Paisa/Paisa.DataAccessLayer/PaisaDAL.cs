﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using System.Data.SqlClient;

namespace Paisa.DataAccessLayer
{
    public class PaisaDAL
    {
        public static int InsertConsumerDAL(BillPayment bill)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertConsumer133889";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Mob_No", bill.MobileNumber);
                cmd.Parameters.AddWithValue("@Biller_Type", bill.BillerType);
                cmd.Parameters.AddWithValue("@ConsumerId", bill.CustomerId);
                cmd.Parameters.AddWithValue("@BillMonth", bill.BillDate);
                cmd.Parameters.AddWithValue("@ModeOfPayment", bill.ModeOfPayment);
                cmd.Parameters.AddWithValue("@Payment_Date", bill.PaymentDate);
                cmd.Parameters.AddWithValue("@Amount", bill.BillAmount);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
