﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paisa.ExceptionHandling
{
   public class UserLoginException : ApplicationException
    {
       
        public UserLoginException() : base()
        {
            
        }

        public UserLoginException(string message) : base(message)
        {
            
        }
    }
}
