﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Paisa.ExceptionHandling
{
    public class PaisaException : ApplicationException
    {
        public PaisaException() : base()
        {

        }

        public PaisaException(string message) : base(message)
        {

        }
    }
}
