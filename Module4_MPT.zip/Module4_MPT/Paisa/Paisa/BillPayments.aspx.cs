﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using Paisa.BuisnessLayer;

namespace Paisa
{
    public partial class BillPayments : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.LogoutVisible = true;
        }

        protected void btnPayBill_Click(object sender, EventArgs e)
        {
            try
            {
                BillPayment bill = new BillPayment();

                bill.BillerType = ddlBillerType.SelectedValue;
                bill.CustomerId = txtId.Text;
                bill.MobileNumber = txtno.Text;
                bill.BillDate = Convert.ToDateTime(txtBillDate.Text);
                bill.PaymentDate = Convert.ToDateTime(txtPaymentDate.Text);
                bill.ModeOfPayment = ddlMode.SelectedValue;
                bill.BillAmount = Convert.ToInt32(txtAmount.Text);

                int rowsAffected = PaisaBL.InsertConsumerBL(bill);

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Bill Payed Successfully');</script>");
                    Response.Redirect("BillPayments.aspx");
                }
                else
                    throw new PaisaException(" Bill not Payed");
            }
            catch (PaisaException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}