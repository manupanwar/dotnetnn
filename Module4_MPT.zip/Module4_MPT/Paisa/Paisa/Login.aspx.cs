﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Paisa.Entity;
using Paisa.ExceptionHandling;
using Paisa.BuisnessLayer;

namespace Paisa
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                UserLogin user = new UserLogin();
                user.UserID = txtUserID.Text;
                user.Password = txtPassword.Text;

                UserLogin validEmp = UserLoginBL.ValidateLoginBL(user);

                if (validEmp != null)
                {
                    Session["user"] =  validEmp.UserName;
                    Response.Redirect("BillPayments.aspx");
                }
                else
                {
                    throw new UserLoginException("EmployeeID/Password is wrong");
                }
            }
            catch (UserLoginException ex)
            {
                lblError.Visible = true;
                lblError.Text = ex.Message;
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}