

CREATE TABLE LoginUser
(
	UserID				varchar(30),
	UserName			VARCHAR(30),
	Password				VARCHAR(20)
)

INSERT INTO LoginUser(UserID, UserName, Password)
VALUES('Jayant', 'Jayant', 'Jayant'),
('Nikita', 'Nikita', 'Nikita')

select * from LoginUser

CREATE PROC usp_ValidateLoginUser
(
	@ID		varchar(30),
	@Pwd		VARCHAR(20)
)
AS
BEGIN
	SELECT UserName 
	FROM LoginUser
	WHERE UserID = @ID AND Password = @Pwd
END


create table Consumer_133889
(
TransactionId   int identity primary key,
MobileNo        varchar(10),
BillerType      varchar(20),
ConsumerId      varchar(30),
BillMonth       Date,
ModeOfPayment   varchar(20),
PaymentDate     date,
Amount          decimal
)

drop table Consumer_133889

drop proc usp_InsertConsumer133889

CREATE PROC usp_InsertConsumer133889
(
	@Mob_No  		    varchar(10),
	@Biller_Type		VARCHAR(20),
	@ConsumerId		    varchar(30),
	@BillMonth			Date,
	@ModeOfPayment		varchar(20),
	@Payment_Date       date,
	@Amount             decimal
)
AS
BEGIN
	INSERT INTO Consumer_133889(MobileNo, BillerType, ConsumerId, BillMonth,ModeOfPayment,PaymentDate,Amount)
	VALUES(@Mob_No, @Biller_Type, @ConsumerId, @BillMonth, @ModeOfPayment, @Payment_Date , @Amount)
END


select * from Consumer_133889