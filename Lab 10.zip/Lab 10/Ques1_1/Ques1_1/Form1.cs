﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Ques1_1
{
    public partial class Form1 : Form

    {
        SqlConnection con=new SqlConnection();
        SqlCommand cmd;
        string query;

        private async static Task<SqlDataReader> RetrieveEmployeeRecord(SqlCommand dbCommand) { return await dbCommand.ExecuteReaderAsync(); }
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            //con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_8thAug2016_Pune;user=sqluser;password=sqluser"); ;
            //con.Open();
          con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_8thAug2016_Pune;user=sqluser;password=sqluser"); 
            await con.OpenAsync();
          }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                 //The Insert DML to add employee record
                 SqlCommand cmd = new SqlCommand
                 ("insert into emp_848833 values(@eno,@enm,@esal,@etyp)", con);
                  //The Parameters
                    cmd.Parameters.Add("@eno", SqlDbType.Int);
                    cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                    cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                    cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);
                    //Assigning Values to parameters
                    cmd.Parameters["@eno"].Value = txtEmpNo.Text ;
                    cmd.Parameters["@enm"].Value = txtName.Text;
                    cmd.Parameters["@esal"].Value = txtSalary.Text;
                    cmd.Parameters["@etyp"].Value = rdPayroll.Checked == true ? "P" : "C";
                    //Execute Insert ....
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Employee Details Saved");
                    }
                catch (SqlException sqlex)
                    {
                        MessageBox.Show(sqlex.Message);
                    }
                }

        private async void btnQuery_Click(object sender, EventArgs e)
        {
            try { SqlDataReader dreader = null; //The Procedure to execute
                SqlCommand cmd = new SqlCommand("GetEmployeeById",con); 
                cmd.CommandType = CommandType.StoredProcedure;
                //define procedure parameter 
                SqlParameter prm; 
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input; 
                prm.ParameterName = "@eno"; 
                cmd.Parameters.Add(prm); 
                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txtEmpNo.Text); 
                //execute 
                dreader = await RetrieveEmployeeRecord(cmd);
                //if employee record found
                if (dreader.Read())
                {
                    txtName.Text = dreader["empname"].ToString();
                    txtSalary.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P") rdPayroll.Checked = true;
                    else rdConsultant.Checked = true; 
                }
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
                }
            catch (SqlException sqlex) 
            { MessageBox.Show(sqlex.Message); }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtEmpNo.Text = "";
            txtName.Text = "";
            txtSalary.Text = "";
            txtEmpNo.Focus();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (txtEmpNo.Text != "")
            {
                DialogResult dia = MessageBox.Show("Are you sure you want to delete the record?");
                if (dia == DialogResult.OK)
                {
                    query = "delete from emp_848833 where  empno=" + txtEmpNo.Text + ";";
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }
                    con.Open();

                    cmd = new SqlCommand(query, con);
                    //execute command for insert/delete/update
                    int i = cmd.ExecuteNonQuery();
                    MessageBox.Show(i + " no. of rows affected!");
                }
                else { MessageBox.Show("Deletion cancelled!"); }
            }

            else MessageBox.Show("Enter employee id to be deleted!");
        }
    }
}
