create table emp_848833
( empno int primary key,
empname varchar(50) not null,
empsal numeric(10,2) check(empsal >= 25000) ,
emptype varchar(1) check(emptype in('C','P'))
)
go
select * from emp_848833
create proc GetEmpById_848833
(
@eno int
)
as
select * from emp_848833 where empno = @eno

