CREATE PROC usp_InsertStudent
(
	@Stud_Code		INT,
	@Stud_Name		VARCHAR(30),
	@Dept_Code		INT,
	@DOB			DATE,
	@Address		VARCHAR(50)
)
AS
BEGIN
	INSERT INTO Student_Master(Student_Code, Student_name, Dept_Code, Student_dob,Student_Address)
	VALUES(@Stud_Code, @Stud_Name, @Dept_Code, @DOB, @Address)
END

GO

CREATE PROC usp_UpdateStudent
(
	@Stud_Code		INT,
	@Dept_Code		INT,
	@Address		VARCHAR(50)
)
AS
BEGIN
	UPDATE Student_Master
	SET Student_Address = @Address,
		Dept_Code = @Dept_Code
	WHERE Student_Code = @Stud_Code
END

GO

CREATE PROC usp_DeleteStudent
(
	@Stud_Code		INT
)
AS
BEGIN
	DELETE FROM Student_Master
	WHERE Student_Code = @Stud_Code
END

GO

CREATE PROC usp_SearchStudent
(
	@Stud_Code		INT
)
AS
BEGIN
	SELECT * FROM Student_Master
	WHERE Student_Code = @Stud_Code
END

GO

CREATE PROC usp_DisplayStudent
AS
BEGIN
	SELECT * FROM Student_Master
END

GO

CREATE PROC usp_RetrieveStudentName
AS
BEGIN
	SELECT Student_Code, Student_name FROM Student_Master
END

GO
CREATE PROC usp_SearchStudentbyDepartment
(
	@DeptCode		INT
)
AS
BEGIN
	SELECT * FROM Student_Master WHERE Dept_Code = @DeptCode
END
GO

CREATE TABLE AdminEmployee
(
	EmployeeID				INT			PRIMARY KEY,
	EmployeeName			VARCHAR(30),
	Password				VARCHAR(20)
)

INSERT INTO AdminEmployee(EmployeeID, EmployeeName, Password)
VALUES(123456, 'Rakesh', 'rakesh'),
(112233, 'Kshmika', 'kshamika')

Go
CREATE PROC usp_ValidateLogin
(
	@EmpID		INT,
	@Pwd		VARCHAR(20)
)
AS
BEGIN
	SELECT EmployeeID, EmployeeName 
	FROM AdminEmployee
	WHERE EmployeeID = @EmpID AND Password = @Pwd
END