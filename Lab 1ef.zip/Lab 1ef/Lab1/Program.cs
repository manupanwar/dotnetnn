﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1
{
    public class Employee
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Title { get; set; }
        public DateTime DOB { get; set; }
        public DateTime DOJ { get; set; }
        public string City { get; set; }


    }
    class Program
    {
        static void Main(string[] args)
        {

            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() { EmployeeID = 1001, FirstName = "Malcolm", LastName = "Daruwalla", Title = "Manager", DOB = Convert.ToDateTime("11/16/1984"), DOJ = Convert.ToDateTime("6/8/2011"), City = "Mumbai" });
            empList.Add(new Employee() { EmployeeID = 1002, FirstName = "Asdin", LastName = "Dhalla", Title = "AsstManager", DOB = Convert.ToDateTime("8/20/1984"), DOJ = Convert.ToDateTime("7/7/2011"), City = "Mumbai" });
            empList.Add(new Employee() { EmployeeID = 1003, FirstName = "Madhavi", LastName = "Oza", Title = "Consultant", DOB = Convert.ToDateTime("11/14/1984"), DOJ = Convert.ToDateTime("4/12/2011"), City = "Pune" });
            empList.Add(new Employee() { EmployeeID = 1004, FirstName = "Saba", LastName = "Shaikh", Title = "SE", DOB = Convert.ToDateTime("6/3/1984"), DOJ = Convert.ToDateTime("2/2/2011"), City = "Pune" });
            empList.Add(new Employee() { EmployeeID = 1005, FirstName = "Nazia", LastName = "Shaikh", Title = "SE", DOB = Convert.ToDateTime("3/8/1984"), DOJ = Convert.ToDateTime("2/2/2011"), City = "Mumbai" });
            empList.Add(new Employee() { EmployeeID = 1006, FirstName = "Amit", LastName = "Pathak", Title = "Consultant", DOB = Convert.ToDateTime("11/7/1984"), DOJ = Convert.ToDateTime("8/8/2011"), City = "Chennai" });
            empList.Add(new Employee() { EmployeeID = 1007, FirstName = "Vijay", LastName = "Natrajan", Title = "Consultant", DOB = Convert.ToDateTime("11/2/1984"), DOJ = Convert.ToDateTime("1/6/2011"), City = "Mumbai" });
            empList.Add(new Employee() { EmployeeID = 1008, FirstName = "Rahul", LastName = "Dubey", Title = "Associate", DOB = Convert.ToDateTime("11/11/1984"), DOJ = Convert.ToDateTime("11/6/2011"), City = "Chennai" });
            empList.Add(new Employee() { EmployeeID = 1009, FirstName = "Suresh", LastName = "Mistry", Title = "Associate", DOB = Convert.ToDateTime("8/12/1984"), DOJ = Convert.ToDateTime("12/3/2011"), City = "Chennai" });
            empList.Add(new Employee() { EmployeeID = 1010, FirstName = "Sumit", LastName = "Shah", Title = "Manager", DOB = Convert.ToDateTime("4/12/1984"), DOJ = Convert.ToDateTime("1/2/2011"), City = "Mumbai" });

            var allEmp = from emp in empList
                         select emp;
            Console.WriteLine("Details of all the employees");
            foreach (Employee e in allEmp)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");
            Console.ReadKey();

            var loc = from emp in empList
                      where emp.City != "Mumbai"
                      select emp;
            Console.WriteLine("Employees whose location is not Mumbai");
            foreach (Employee e in loc)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

            Console.WriteLine("\n");
            var emptitle = from emp in empList
                           where emp.Title == "AsstManager"
                           select emp;
            Console.WriteLine("Employee whose title is AsstManager");
            foreach (Employee e in emptitle)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }

            Console.WriteLine("\n");

            var empname = from emp in empList
                          where emp.LastName.StartsWith("S")
                          select emp;
            Console.WriteLine("Employees whose last name starts with S");
            foreach (Employee e in empname)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");

            var doj = from emp in empList
                      where emp.DOJ < Convert.ToDateTime("1/1/2015")
                      select emp;
            Console.WriteLine("Employees who joined before 1/1/2015");
            foreach (Employee e in doj)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");

            var dob = from emp in empList
                      where emp.DOJ > Convert.ToDateTime("1/1/1990")
                      select emp;
            Console.WriteLine("Employees whose dob is after 1/1/1990");
            foreach (Employee e in dob)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");

            var desgn = from emp in empList
                        where emp.Title == "Consultant" || emp.Title == "Associate"
                        select emp;
            Console.WriteLine("Employees whose designation is Consultant or Associate");
            foreach (Employee e in desgn)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");

            var count = empList.Count;
            Console.WriteLine("Total number of employees : " + count);


            Console.WriteLine("\n");
            var chennaiCount = from emp in empList
                               where emp.City == "Chennai"
                               group emp by emp.City into g
                               select new
                               {
                                   City = g.Key,
                                   NoofEmp = g.Count()
                               };
            Console.WriteLine("Total number of employees belonging to chennai");
            foreach (var e in chennaiCount)
            {
                Console.WriteLine(e.City + " " + e.NoofEmp);
            }
            Console.WriteLine("\n");

            var maxID = (from e in empList select e.EmployeeID).Max();
            Console.WriteLine("Employee with the Max ID is : " + maxID);
            Console.WriteLine("\n");

            var empJoin = from emp in empList
                          where emp.DOJ > Convert.ToDateTime("1/1/2015")
                          select emp;

            foreach (var e in empJoin)
            {
                Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
            }
            Console.WriteLine("\n");

            var n = from emp in empList
                    where emp.Title != "Associate"
                    group emp by emp.Title into g
                    select new
                    {
                        Title = g.Key,
                        NoofEmp = g.Count()
                    };
            foreach (var e in n)
            {
                Console.WriteLine(e.Title + " " +e.NoofEmp);
            }
            Console.WriteLine("\n");

            var empCity = empList.ToLookup(e => e.City);
            Console.WriteLine("City wise employee list");
            foreach (IGrouping<string, Employee> g in empCity)
            {
                Console.WriteLine("\nCity: " + g.Key);
                foreach (Employee e in g)
                {
                    Console.WriteLine(e.EmployeeID + " " + e.FirstName + " " + e.LastName + " " + e.Title + " " + e.DOB + " " + e.DOJ + " " + e.City);
                }
            }
            Console.WriteLine("\n");

            var query = from emp in empList
                        group emp by emp.City into cityGroups
                        select new
                        {
                            City = cityGroups.Key,
                            Titles = from t in cityGroups
                                     group t by t.Title into titleGroups
                                    select new
                                    {
                                        Title = titleGroups.Key,
                                    }
                        };
            Console.WriteLine("City and Title wise Grouping");

            foreach (var e in query)
                {
                    Console.WriteLine(e.City+" "+e.Titles);
                }
            Console.WriteLine("\n");
        }
        
    }
    
}
