create table MailUsers_94163
(
	MailUserId		varchar(20)	primary key,
	MailUserName	varchar(50),	
	MailUserPwd		varchar(20),	
	AccountCreationDate	DateTime,
	Hobbies			varchar(50)	
);

create table MailsInBox_94163
(
	MailTranNo		Int Identity primary key,
	FromMailUserId	varchar(20),	
	ToMailUserId	varchar(20),	
	Subject			varchar(50),	
	MailText		varchar(50),	
	IsMailNew		varchar(20),	
	MailDateTime	DateTime
	foreign key(FromMailUserId) references MailUsers_94163(MailUserId),
	foreign key(ToMailUserId) references MailUsers_94163(MailUserId)
);




(



	@FromMailUserId		varchar	(20),



	@ToMailUserId		varchar	(20),



	@Subject			varchar	(50),



	@MailText			varchar	(50)



)



AS



declare @to varchar(20),@from varchar(20)



BEGIN







	select @to=MailUserId from MAilUSers_0_94163 where MailUserName=@ToMailUserId







	select @from=MailUserId from MAilUSers_0_94163 where MailUserName=@FromMailUserId







	insert into MailsInBox__94163(FromMailUserId,ToMailUserId,Subject,MailText,IsMailNew,MailDateTime)



	values(@from,@to,@Subject,@MailText,'Yes',getdate())



END