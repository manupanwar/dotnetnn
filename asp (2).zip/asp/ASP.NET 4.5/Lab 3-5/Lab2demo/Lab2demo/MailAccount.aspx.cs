﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mail.Entity;
using Mail.Exception;
using Mail.MailServiceBL;
using System.Text;

namespace Lab2demo
{
    public partial class MailAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtToday.Text = DateTime.Now.ToShortDateString();
        }

        protected void cvHobbies_ServerValidate(object source, ServerValidateEventArgs args)
        {

            if (cbxDrawing.Checked || cbxReading.Checked || cbxSports.Checked)
            {
                args.IsValid = true;
            }
            else
            {
                args.IsValid = false;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                MailUsers user = new MailUsers();
                user.MailUserName = txtUserName.Text;
                user.MailUserPassword = txtPassword.Text;
                StringBuilder sb = new StringBuilder();
                if (cbxDrawing.Checked)
                {
                    sb.Append(cbxDrawing.Text);
                }
                else if (cbxReading.Checked)
                {
                    sb.Append(cbxReading.Text);
                }
                else if (cbxSports.Checked)
                {
                    sb.Append(cbxSports.Text);
                }
                user.Hobbies = sb.ToString();
                int rowadded = MailService.AddUser(user);
                if (rowadded<0)
                {
                    throw new MailException("Invalid user details");
                }


            }
            catch (MailException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>"); 
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>"); 
            }
        }


    }
}