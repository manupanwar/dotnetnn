﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab2demo
{
    public partial class ChangeProfile : System.Web.UI.Page
    {
        public static string format;
        static string username, password;
        protected void Page_Load(object sender, EventArgs e)
        {
            format = "Grid View";
            HttpCookie ck = Request.Cookies["MyCookie"];

            if (ck != null)
            {

                username = ck.Values["username"];
                password = ck.Values["password"];
                Response.Write("<script>alert('" + username + "')</script>");

            }
            else
            {
                string msg = "Login to access";
                Response.Write("<script>alert('" + msg + "')</script>");
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Login in')", true);
                Response.Redirect("SignInPage.aspx");
            }
        }

        protected void ddlformat_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            format = ddlformat.SelectedItem.ToString();
        }
    }
}