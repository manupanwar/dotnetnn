﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mail.Entity;
using Mail.Exception;
using Mail.MailServiceBL;
using System.Text;

namespace Lab2demo
{
    public partial class SignInPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string username = txtUserName.Text;
                string password = txtPassword.Text;
               
                string userid = MailService.validateUser(username,password);
                if (userid==null)
                {
                    throw new MailException("Invalid credentials");
                }
                else
                {
                    HttpCookie ck = new HttpCookie("MyCookie");
                    ck.Expires = DateTime.Now.AddMinutes(10);
                    ck.Values.Add("username", txtUserName.Text);
                    ck.Values.Add("password", txtPassword.Text);
                    Response.Cookies.Add(ck);
                    Response.Redirect("InBox.aspx");
                }


            }
            catch (MailException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>"); 
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>"); 
            }
        }

        //protected void btnRegister_Click(object sender, EventArgs e)
        //{
        //    Response.Redirect("MailAccount.aspx");
        //}
    }
}