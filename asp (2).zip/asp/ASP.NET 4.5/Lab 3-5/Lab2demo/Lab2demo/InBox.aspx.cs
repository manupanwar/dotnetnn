﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab2demo
{
    public partial class InBox : System.Web.UI.Page
    {
        static string username, password;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (ChangeProfile.format=="Grid View")
            {
                gvInbox.Visible = true;
                dvInbox.Visible = false;
            }
            else
            {
                gvInbox.Visible = false;
                dvInbox.Visible = true;
            }

            HttpCookie ck = Request.Cookies["MyCookie"];

            if (ck != null)
            {
                
                username = ck.Values["username"];
                password = ck.Values["password"];
                //Response.Write("<script>alert('" + username + "')</script>");

            }
            else
            {
                Response.Write("<script>alert('Login to access this page')</script>");
                Response.Redirect("SignInPage.aspx");
            }
        }
    }
}