﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Mail.Entity;
using Mail.Exception;
using Mail.MailServiceBL;
using System.Text;

namespace Lab2demo
{
    public partial class SendMail : System.Web.UI.Page
    {
        static string username, password;
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie ck = Request.Cookies["MyCookie"];

            if (ck != null)
            {
                
                username=ck.Values["username"];
                password= ck.Values["password"];
                Response.Write("<script>alert('" + username + "')</script>"); 
                
            }
            else
            {
                string msg = "Login to access";
                Response.Write("<script>alert('"+msg+"')</script>");
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Login in')", true);
                Response.Redirect("SignInPage.aspx");
            }
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                MailsInBox mail = new MailsInBox();
                mail.ToMailUserId = txtSendto.Text;
                mail.Subject = txtSubject.Text;
                mail.MailText = txtBody.Text;
                mail.FromMailUserId = username;
                
                int rowadded = MailService.AddMail(mail);
                if (rowadded < 0)
                {
                    throw new MailException("Invalid mail");
                }


            }
            catch (MailException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "')</script>");
            }
        }
    }
}