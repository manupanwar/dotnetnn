﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mail.Exception
{
    public class MailException:ApplicationException
    {
        public MailException()
            : base()
        { }

        public MailException(string msg)
            : base(msg)
        { }
    }
}
