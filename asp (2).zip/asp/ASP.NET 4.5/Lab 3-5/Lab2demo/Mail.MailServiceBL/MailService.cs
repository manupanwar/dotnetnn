﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mail.Entity;
using Mail.Exception;
using Mail.DAL;

namespace Mail.MailServiceBL
{
    public class MailService
    {
        public static int AddUser(MailUsers newUser)
        {
            int rowadded;
            try
            {
                rowadded = MailDAL.AddUser(newUser);
            }
            catch (MailException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowadded;
        }

        public static string validateUser(string username, string password)
        {
            string userid;
            try
            {
                userid = MailDAL.validateUser(username, password);
            }
            catch (MailException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userid;
        }

        public static int AddMail(MailsInBox newMail)
        {
            int rowadded;
            try
            {
                rowadded = MailDAL.AddMail(newMail);
            }
            catch (MailException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowadded;
        }
    }
}
