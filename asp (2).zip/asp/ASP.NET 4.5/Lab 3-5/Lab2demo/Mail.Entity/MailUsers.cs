﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mail.Entity
{
    public class MailUsers
    {
        public string MailUserId { get; set; }
        public string MailUserName { get; set; }
        public string MailUserPassword { get; set; }
        public DateTime AccountCreationDate { get; set; }
        public string Hobbies { get; set; }

    }
}
