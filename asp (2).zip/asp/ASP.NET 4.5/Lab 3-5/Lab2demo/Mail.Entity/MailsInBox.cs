﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mail.Entity
{
    public class MailsInBox
    {

        public int MailTranNo { get; set; }
        public string FromMailUserId { get; set; }
        public string ToMailUserId { get; set; }
        public string Subject { get; set; }
        public string MailText { get; set; }
        public string IsMailNew { get; set; }
        public DateTime MailDateTime { get; set; }

    }
}
