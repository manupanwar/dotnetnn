﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Mail.DAL
{
    class CommandClass
    {
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;
            try
            {
                //creating a sql connection
                SqlConnection con = new SqlConnection(ConfigurationClass.ConnectionString);
                //creating new command as cmd
                cmd = new SqlCommand();
                cmd.Connection = con;
                //setting the command type as Stored Procedure
                cmd.CommandType = CommandType.StoredProcedure;

            }
            //catch sql Exception if any
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return cmd;
        }
    }
}
