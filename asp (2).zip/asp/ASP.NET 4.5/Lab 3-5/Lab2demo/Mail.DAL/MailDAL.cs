﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Mail.Entity;
using Mail.Exception;

namespace Mail.DAL
{
    public class MailDAL
    {
        public static int AddUser(MailUsers newUser)
        {
            int rowsAdded = 0;
            try
            {
                //creating new sql command
                SqlCommand cmd = CommandClass.CreateCommand();
                //giving the procedure name as text to execute
                cmd.CommandText = "usp_addUserMail_848831";

                //Adding the values to the Table
                cmd.Parameters.AddWithValue("@username", newUser.MailUserName);
                cmd.Parameters.AddWithValue("@password", newUser.MailUserPassword);
                cmd.Parameters.AddWithValue("@hobbies", newUser.Hobbies);


                //open the sql connection
                cmd.Connection.Open();
                rowsAdded = cmd.ExecuteNonQuery();
                //closing the sql connection
                cmd.Connection.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return rowsAdded;

        }

        public static string validateUser(string username, string password)
        {
            string userid = null;

            try
            {
                SqlCommand cmd = CommandClass.CreateCommand();
                cmd.CommandText = "usp_ITIM_ValidateUsername_848831";

                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    userid = dr["MailUserId"].ToString();
                }

                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return userid;
        }

        public static int AddMail(MailsInBox newMail)
        {
            int rowsAdded = 0;
            try
            {
                //creating new sql command
                SqlCommand cmd = CommandClass.CreateCommand();
                //giving the procedure name as text to execute
                cmd.CommandText = "usp_addMail_848831";

                //Adding the values to the Table
                cmd.Parameters.AddWithValue("@FromMailUserId", newMail.FromMailUserId);
                cmd.Parameters.AddWithValue("@ToMailUserId", newMail.ToMailUserId);
                cmd.Parameters.AddWithValue("@Subject", newMail.Subject);
                cmd.Parameters.AddWithValue("@MailText", newMail.MailText);

                //open the sql connection
                cmd.Connection.Open();
                rowsAdded = cmd.ExecuteNonQuery();
                //closing the sql connection
                cmd.Connection.Close();

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return rowsAdded;

        }

    }
}
