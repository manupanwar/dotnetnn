﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Mail.Entity;

namespace Mail.DAL
{
    public class ConfigurationClass
    {

        private static string connectionString;
        private static string dataProvider;
        public static string DataProvider
        {
            get
            {
                return dataProvider;
            }
            set
            {
                dataProvider = value;
            }
        }
        public static string ConnectionString
        {
            get
            {
                return connectionString;
            }
            set
            {
                connectionString = value;
            }
        }

        static ConfigurationClass()
        {
            ConnectionString = ConfigurationManager.ConnectionStrings["EMPCS"].ConnectionString;
            DataProvider = ConfigurationManager.ConnectionStrings["EMPCS"].ProviderName;
        }
    }
}
