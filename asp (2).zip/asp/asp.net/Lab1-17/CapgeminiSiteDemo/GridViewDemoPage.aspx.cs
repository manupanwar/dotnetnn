﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class GridViewDemoPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            PopulateGrid();

    }


    private void PopulateGrid()
    {
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select * from customer_094276", con);

        DataSet ds = new DataSet();
        da.Fill(ds, "cust");

        grdcustomer.DataSource = ds.Tables["cust"];
        grdcustomer.DataBind();
    }

    protected void grdcustomer_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdcustomer.PageIndex = e.NewPageIndex;
        PopulateGrid();       

    }
    protected void grdcustomer_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdcustomer.EditIndex = -1;
        PopulateGrid();
    }
    protected void grdcustomer_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdcustomer.EditIndex = e.NewEditIndex;
        PopulateGrid();
    }
    protected void grdcustomer_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        
        string custid,custname,city,crlimit;

        //when update button is clicked the row is in edit item template 
        //Get the reference of the controls in edit item template to get the entered values
        Label lb = (Label)grdcustomer.Rows[e.RowIndex].FindControl("lblcustomerid");
            custid = lb.Text;

            TextBox tb = (TextBox)grdcustomer.Rows[e.RowIndex].FindControl("txtcustomername");
            custname = tb.Text;

            tb = (TextBox)grdcustomer.Rows[e.RowIndex].FindControl("txtcity");
            city = tb.Text;

            tb = (TextBox)grdcustomer.Rows[e.RowIndex].FindControl("txtcredit");
            crlimit = tb.Text;
            string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectsring);
            SqlCommand cmd = new SqlCommand("update customer_094276 set " + "customername=@cname,city=@city,creditlimit=@credit " + " where customerid= @cid", con);
            cmd.Parameters.AddWithValue("@cname", custname);
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@credit", crlimit);
            cmd.Parameters.AddWithValue("@cid", custid);

            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            grdcustomer.EditIndex = -1;
            PopulateGrid();
    }
}