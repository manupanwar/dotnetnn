﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class CategoryList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            PopulateGridView();

    }

    private void PopulateGridView()
    {
        DataSet ds = null;
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select * from category order by categoryname", con);

        ds = new DataSet();
        da.Fill(ds, "procat");


        grdcategory.DataSource = ds.Tables["procat"];
        grdcategory.DataBind();
    }

}