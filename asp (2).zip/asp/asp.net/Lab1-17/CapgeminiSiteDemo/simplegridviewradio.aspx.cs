﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class simplegridviewradio : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateDropDown();
            PopulateGridView();
        }
    }
    protected void rdbtn_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateGridView();
    }

    private void PopulateDropDown()
    {
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select * from category order by categoryname", con);

        DataSet ds = new DataSet();
        da.Fill(ds, "cat");
        rdbtn.DataSource = ds.Tables["cat"];
        rdbtn.DataTextField = "categoryname";
        rdbtn.DataValueField = "categoryid";
        rdbtn.DataBind();

    }

    private void PopulateGridView()
    {
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select productid,productname,unitprice,unitsinstock from product " + " where categoryid = @catid  order by productname", con);
        da.SelectCommand.Parameters.Add("@catid", SqlDbType.Int);
        da.SelectCommand.Parameters["@catid"].Value = rdbtn.SelectedValue;

        DataSet ds = new DataSet();
        da.Fill(ds, "prod");
        grdproduct.DataSource = ds.Tables["prod"];
        grdproduct.DataBind();

    }
}