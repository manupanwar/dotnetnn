﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AjaxDemo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        System.Threading.Thread.Sleep(3000);
        int r = int.Parse(txtno1.Text) + int.Parse(txtno2.Text);
        label3.Text = r.ToString();
    }
}