﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class ProductCatalogue : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            PopulateDataList();

    }

    private void PopulateDataList()
    {
        DataSet ds = null;
        //check whether information is in Application object
        //if not retrieve details and fill  Application object
        if (Application["productcategories"] == null)
        {
            string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
            SqlConnection con = new SqlConnection(connectsring);
            SqlDataAdapter da = new SqlDataAdapter("select * from product where categoryid = @catid  order by productname", con);
            da.SelectCommand.Parameters.Add("@catid", SqlDbType.Int);
            da.SelectCommand.Parameters["@catid"].Value = Request["catid"];

            ds = new DataSet();
            da.Fill(ds, "prod");

            Application["products"] = ds;
        }
        else
            ds = Application["products"] as DataSet;

        dlstproducts.DataSource = ds.Tables["prod"];
        dlstproducts.DataBind();
    }

    protected void dlstproducts_ItemCommand(object source, DataListCommandEventArgs e)
    {
        if (e.CommandName == "Add")
        {
            Label l;

            List<Product> cart;
            //find if cart is created for session
            if (Session["cart"] == null)
            {
                cart = new List<Product>();
                Session["cart"] = cart;
            }
            else
                cart = Session["cart"] as List<Product>;
            //Get the product details from the controls placed in Data List Item
            Product prod = new Product();
            l = e.Item.FindControl("lblname") as Label;
            prod.ProductId = Convert.ToInt32(l.Text);

            l = e.Item.FindControl("lblid") as Label;
            prod.ProductName = l.Text;

            l = e.Item.FindControl("lblstock") as Label;
            prod.UnitsInStock = Convert.ToInt32(l.Text);

            l = e.Item.FindControl("lblprice") as Label;
            prod.UnitPrice = Convert.ToDouble(l.Text);

            prod.QtyOrdered = 1;
            //Add it to cart	
            cart.Add(prod);
        }
    }
    	

}