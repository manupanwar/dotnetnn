﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

public partial class simplegridview : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PopulateDropDown();
            PopulateGridView();
        }


    }

      private void PopulateDropDown()
    {
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select * from category order by categoryname", con);

        DataSet ds = new DataSet();
        da.Fill(ds, "cat");
        dncategory.DataSource = ds.Tables["cat"];
        dncategory.DataTextField = "categoryname";
        dncategory.DataValueField = "categoryid";
        dncategory.DataBind();

    }

    private void PopulateGridView()
    {
        string connectsring = ConfigurationManager.ConnectionStrings["labdemoconnectstring"].ConnectionString;
        SqlConnection con = new SqlConnection(connectsring);
        SqlDataAdapter da = new SqlDataAdapter("select productid,productname,unitprice,unitsinstock from product " + " where categoryid = @catid  order by productname", con);
        da.SelectCommand.Parameters.Add("@catid", SqlDbType.Int);
        da.SelectCommand.Parameters["@catid"].Value = dncategory.SelectedValue;

        DataSet ds = new DataSet();
        da.Fill(ds, "pro");
        grdproduct.DataSource = ds.Tables["pro"];
        grdproduct.DataBind();

    }

    protected void dncategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        PopulateGridView();
    }
}