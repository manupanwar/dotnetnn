﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (PreviousPage != null && PreviousPage.IsCrossPagePostBack)
        {
            TextBox txtbox = PreviousPage.FindControl("txtname") as TextBox;
            if (txtbox != null)
            {
                Label1.Text = "Welcome User " + txtbox.Text;
            }
            else
                Label1.Text = "No txtname Text Box found in earlier page";
        }
        else
            Label1.Text = "You directly came to this Page2.aspx and not through Page1.aspx";

    }
}