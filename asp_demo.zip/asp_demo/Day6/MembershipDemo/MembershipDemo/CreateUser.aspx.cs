﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace MembershipDemo
{
    public partial class CreateUser : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void cuw_CreatedUser(object sender, EventArgs e)
        {
            MembershipCreateStatus status = MembershipCreateStatus.Success;

            if (cuw.UserName != "" && cuw.Password != "" && cuw.ConfirmPassword != "" && cuw.Question != "" && cuw.Answer != "" && cuw.Email != "")
            {
                Membership.CreateUser(cuw.UserName, cuw.Password, cuw.Email, cuw.Question, cuw.Answer, true, out status);
            }
            else
                Response.Write("<script>alert('Please provide data for all fields');</script>");
        }

        protected void cuw_ContinueButtonClick(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}