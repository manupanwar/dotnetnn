﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    public class AdminEmployeeException : ApplicationException
    {
        public AdminEmployeeException()
            : base()
        { }

        public AdminEmployeeException(string message)
            : base(message)
        { }
    }
}
