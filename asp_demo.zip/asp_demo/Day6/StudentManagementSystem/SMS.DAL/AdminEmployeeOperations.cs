﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using System.Data;
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class AdminEmployeeOperations
    {
        public static AdminEmployee ValidateLogin(AdminEmployee emp)
        {
            AdminEmployee validEmp = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_ValidateLogin";
                cmd.Parameters.AddWithValue("@EmpID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@Pwd", emp.Password);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    validEmp = new AdminEmployee();
                    dr.Read();
                    validEmp.EmployeeID = (int)dr["EmployeeID"];
                    validEmp.EmployeeName = dr["EmployeeName"].ToString();
                }
                else
                    throw new AdminEmployeeException("UserID/Password is wrong");
            }
            catch(AdminEmployeeException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return validEmp;
        }
    }
}
