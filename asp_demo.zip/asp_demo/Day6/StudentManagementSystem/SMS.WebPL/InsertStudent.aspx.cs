﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.WebPL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                Response.Redirect("Login.aspx");
            }

            Master.LogoutVisible = true;
            Master.MenuVisible = true;
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            try 
            {
                Student stud = new Student();

                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtStudDob.Text);
                stud.Address = txtAddress.Text;

                int rowsAffected = StudentValidation.InsertStudent(stud);

                if (rowsAffected > 0)
                {
                    Response.Write("<script>alert('Student Data inserted Successfully');</script>");
                    Response.Redirect("Home.aspx");
                }
                else
                    throw new StudentException("Student Record not Inserted");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}