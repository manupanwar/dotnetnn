﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MultipleUpdatePanelDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblPage.Text = DateTime.Now.ToString();
            lblUp1.Text = DateTime.Now.ToString();
            lblUp2.Text = DateTime.Now.ToString();
            lblUp3.Text = DateTime.Now.ToString();
        }
    }
}