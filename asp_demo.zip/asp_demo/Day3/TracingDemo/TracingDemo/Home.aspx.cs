﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TracingDemo
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            HttpCookie ck = new HttpCookie("cust");
            ck.Values.Add("name", txtName.Text);
            ck.Values.Add("city", txtCity.Text);
            Response.Cookies.Add(ck);

            Session["Name"] = txtName.Text;
            Session["City"] = txtCity.Text;

            Application["Name"] = txtName.Text;
            Application["City"] = txtCity.Text;

            Response.Redirect("Page2.aspx?name=" + txtName.Text);
        }
    }
}