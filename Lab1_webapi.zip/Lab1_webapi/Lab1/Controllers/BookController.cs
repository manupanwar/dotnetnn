﻿using Lab1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Lab1.Controllers
{
    public class BookController : ApiController
    {
        List<Book> booklist = new List<Book>()
    {
        new Book {ID=70536,Title="Programmining in CSharp",Year=2013,Price=999.99M,Genre="Programming"},
        new Book {ID=70486,Title="Programmining ASP.NET MVC 4",Year=2014,Price=1235.88M,Genre="Programming"},
        new Book {ID=1008,Title="Microprocessors",Year=2005,Price=678.00M,Genre="Computers"},
        new Book {ID=2341,Title="Cisco Certification",Year=2010,Price=346.56M,Genre="Networking"}
    };

        public IEnumerable<Book> GetBook()
        {
            return booklist;
        }

        public IHttpActionResult GetBook(int ID)
        {
            var book = booklist.FirstOrDefault((b) => b.ID == ID);

            if(book==null)
            { 
                return NotFound();
            }
            else
            {
                return Ok(book);
            }
        }

        public void AddBook(Book book)
        {
            if(book == null)
            {
                throw new ArgumentException("Invalid Object");
            }
            booklist.Add(book);
        }

        public void DeleteBook(int id)
        {
            booklist.RemoveAll((b) => b.ID == id);
        }
    }
}
