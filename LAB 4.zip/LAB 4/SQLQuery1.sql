create table customer88
(
customerid int identity primary key,
customername varchar(50),
city varchar(30),
creditlimit numeric(10,2)
);

select * from customer88

insert into customer88
values('Jace','Georgia',50000);

insert into customer88
values('Kendall','LA',54854);
insert into customer88
values('Kiyara','Captown',6688);
insert into customer88
values('charlotte','UK',45745);
insert into customer88
values('Raksha','New Jersey',58978);
