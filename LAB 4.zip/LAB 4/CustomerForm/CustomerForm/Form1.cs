﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CustomerForm
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_8thAug2016_Pune;user=sqluser;password=sqluser;");
            con.Open();
            ds = new DataSet();
            //select - For Data Retrieval
            da = new SqlDataAdapter("select * from customer88", con);
            da.Fill(ds, "cust");
            grdCustomers.DataSource = ds.Tables["cust"];
        }

        private void cmbcolumnlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = cmbcolumnlist.Text;
        }

        private void btnShow_Click(object sender, EventArgs e)
        {
        ds.Tables["cust"].DefaultView.RowFilter = "City like '" + txtcity.Text + "'";
        }
    }
}
