﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace CustomerForm
{
    public partial class CustomerForm : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_8thAug2016_Pune;user=sqluser;password=sqluser;");//integrated security=sspi for windows authentication
            da = new SqlDataAdapter("select * from customer_00094163", con);
            ds = new DataSet();

            da.Fill(ds, "cust");
            grdCustomers.DataSource = ds.Tables["cust"];
            da.Update(ds.Tables["cust"]);
            

        }

        private void cmbcolumnlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = cmbcolumnlist.Text;
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like '" +txtcity.Text + "'";
        }

        private void grdCustomers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

     
    }
}
