﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace SuppliersForm
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
         con = new SqlConnection(@"server=NDAMSSQL\SQLILEARN;database=Training_8thAug2016_Pune;user=sqluser;password=sqluser;");//integrated security=sspi for windows authentication
         da = new SqlDataAdapter("select * from suppliers_94163", con);
            ds = new DataSet();
            da.Fill(ds, "sup");
            grdCustomers.DataSource = ds.Tables["sup"];
            
           
        }

        private void cmbcolumnlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["sup"].DefaultView.Sort = cmbcolumnlist.Text;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            
            DataRow row = ds.Tables["sup"].NewRow();
            ds.Tables["sup"].Rows.Add(row);
            row["SupplierId"] = Convert.ToInt32(txtsupplierId.Text);
            row["Suppliername"] = txtsuppliername.Text;
            row["city"] = txtcity.Text;
            row["ContactNo"] = txtcontactno.Text;
            row["CreditBalance"] = Convert.ToDouble(txtcreditbalance.Text);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da.Update(ds.Tables["sup"]);
        }

   

  

   
    }
}
