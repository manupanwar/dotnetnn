﻿namespace SuppliersForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grdCustomers = new System.Windows.Forms.DataGridView();
            this.cmbcolumnlist = new System.Windows.Forms.ComboBox();
            this.txtsupplierId = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtsuppliername = new System.Windows.Forms.TextBox();
            this.txtcity = new System.Windows.Forms.TextBox();
            this.txtcontactno = new System.Windows.Forms.TextBox();
            this.txtcreditbalance = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdCustomers)).BeginInit();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 185);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Sort Details On";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Supplier ID";
            // 
            // grdCustomers
            // 
            this.grdCustomers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdCustomers.Location = new System.Drawing.Point(240, 8);
            this.grdCustomers.Name = "grdCustomers";
            this.grdCustomers.Size = new System.Drawing.Size(246, 213);
            this.grdCustomers.TabIndex = 8;
            // 
            // cmbcolumnlist
            // 
            this.cmbcolumnlist.FormattingEnabled = true;
            this.cmbcolumnlist.Items.AddRange(new object[] {
            "City",
            "SupplierName"});
            this.cmbcolumnlist.Location = new System.Drawing.Point(94, 185);
            this.cmbcolumnlist.Name = "cmbcolumnlist";
            this.cmbcolumnlist.Size = new System.Drawing.Size(124, 21);
            this.cmbcolumnlist.TabIndex = 7;
            this.cmbcolumnlist.SelectedIndexChanged += new System.EventHandler(this.cmbcolumnlist_SelectedIndexChanged);
            // 
            // txtsupplierId
            // 
            this.txtsupplierId.Location = new System.Drawing.Point(95, 8);
            this.txtsupplierId.Name = "txtsupplierId";
            this.txtsupplierId.Size = new System.Drawing.Size(124, 20);
            this.txtsupplierId.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Supplier Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "city";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 114);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "ContactNo";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 151);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 15;
            this.label6.Text = "Credit balance";
            // 
            // txtsuppliername
            // 
            this.txtsuppliername.Location = new System.Drawing.Point(94, 48);
            this.txtsuppliername.Name = "txtsuppliername";
            this.txtsuppliername.Size = new System.Drawing.Size(124, 20);
            this.txtsuppliername.TabIndex = 16;
            // 
            // txtcity
            // 
            this.txtcity.Location = new System.Drawing.Point(95, 84);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(124, 20);
            this.txtcity.TabIndex = 17;
            // 
            // txtcontactno
            // 
            this.txtcontactno.Location = new System.Drawing.Point(94, 114);
            this.txtcontactno.Name = "txtcontactno";
            this.txtcontactno.Size = new System.Drawing.Size(124, 20);
            this.txtcontactno.TabIndex = 18;
            // 
            // txtcreditbalance
            // 
            this.txtcreditbalance.Location = new System.Drawing.Point(95, 151);
            this.txtcreditbalance.Name = "txtcreditbalance";
            this.txtcreditbalance.Size = new System.Drawing.Size(124, 20);
            this.txtcreditbalance.TabIndex = 19;
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(240, 227);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(246, 23);
            this.btnupdate.TabIndex = 20;
            this.btnupdate.Text = "Update";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(513, 262);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.txtcreditbalance);
            this.Controls.Add(this.txtcontactno);
            this.Controls.Add(this.txtcity);
            this.Controls.Add(this.txtsuppliername);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grdCustomers);
            this.Controls.Add(this.cmbcolumnlist);
            this.Controls.Add(this.txtsupplierId);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdCustomers)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView grdCustomers;
        private System.Windows.Forms.ComboBox cmbcolumnlist;
        private System.Windows.Forms.TextBox txtsupplierId;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtsuppliername;
        private System.Windows.Forms.TextBox txtcity;
        private System.Windows.Forms.TextBox txtcontactno;
        private System.Windows.Forms.TextBox txtcreditbalance;
        private System.Windows.Forms.Button btnupdate;
    }
}

