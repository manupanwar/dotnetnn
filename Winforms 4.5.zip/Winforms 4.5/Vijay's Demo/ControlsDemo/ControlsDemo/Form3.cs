﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsDemo
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string erromsg = "";

            if (txtName.Text == string.Empty)
            {
                erromsg += "Name cannot be blank\n";
            }

            if (txtContact.Text == string.Empty)
            {
                erromsg += "Contact cannot be blank\n";
            }
            else
            {
                if (txtContact.TextLength > 10 || txtContact.TextLength < 10)
                {
                    erromsg += "Contact number must be of 10 digits\n";
                }
            }

            if (erromsg != "")
            {
                MessageBox.Show(erromsg);
            }
            else
            {
                MessageBox.Show("Valid Data");
            }
        }
    }
}
