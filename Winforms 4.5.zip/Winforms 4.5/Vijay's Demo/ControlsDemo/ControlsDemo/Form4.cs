﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsDemo
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (txtName.Text == string.Empty)
            {
                errorProvider1.
                    SetError(txtName, "Name cannnot be blank");
            }

            if (txtContact.Text == string.Empty)
            {
                errorProvider1.
                    SetError(txtContact, "Contact cannot be blank");
            }
            else
            {
                if (txtContact.TextLength != 10)
                {
                    errorProvider1.
                        SetError(txtContact, "Contact number must be of 10 digits");
                }
            }
        }
    }
}
