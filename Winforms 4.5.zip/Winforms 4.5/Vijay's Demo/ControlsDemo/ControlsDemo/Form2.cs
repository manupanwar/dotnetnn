﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsDemo
{
    public partial class Form2 : Form
    {
        String strmsg = "";
        public Form2()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" ||
                txtAddress.Text == "" ||
                dtpDOB.Value == DateTime.Now ||
                cboAddressType.Text == "(Select)")
            {
                MessageBox.Show("Please enter valid data");
            }
            else
            {
                strmsg += "Name =" + txtName.Text;
                strmsg += "\nDate of Birth = " + dtpDOB.Value;

                if (radMale.Checked)
                    strmsg += "\nGender = " + radMale.Text;
                else
                    strmsg += "\nGender = " + radFemale.Text;

                strmsg += "\nContact No = " + txtContact.Text;
                strmsg += "\nAddress = " + txtAddress.Text;
                strmsg += "\nAddress Type = " + cboAddressType.Text;

                MessageBox.Show("Following details submitted successfully\n"+strmsg);

            }
        }
    }
}
