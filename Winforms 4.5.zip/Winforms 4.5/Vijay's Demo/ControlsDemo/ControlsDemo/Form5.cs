﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ControlsDemo
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            cboProduct.Items.Add("Mouse");
            cboProduct.Items.Add("Hard Disk");
            cboProduct.Items.Add("Pen Drive");
        }

        private void cboProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboProduct.SelectedIndex == 0)
            {
                txtName.Text = "Mouse";
                txtPrice.Text = "199.99";
                txtUnits.Text = "89";
                pictureBox1.Image = Image.FromFile("../../mouse.jpg");
            }

            else if (cboProduct.SelectedIndex == 1)
            {
                txtName.Text = "Hard Disk";
                txtPrice.Text = "4500.99";
                txtUnits.Text = "189";
                pictureBox1.Image = Image.FromFile("../../hdd.jpg");
            }

            else if (cboProduct.SelectedIndex == 2)
            {
                txtName.Text = "Pendrive";
                txtPrice.Text = "350.99";
                txtUnits.Text = "100";
                pictureBox1.Image = Image.FromFile("../../pendrive.jpg");
            }
        }

        private void chkShowImage_CheckedChanged(object sender, EventArgs e)
        {
            if (chkShowImage.Checked)
                pictureBox1.Visible = true;
            else
                pictureBox1.Visible = false;
        }
    }
}
