﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDIApplicationDemos
{
    public partial class MainWindow : Form
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isopen = false;

            foreach (Form form in Application.OpenForms)
            {
                if (form.Text == "Form1")
                {
                    isopen = true;
                    form.Focus();
                    break;
                }
            }
            if (isopen == false)
            {
                Form1 f = new Form1();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void customerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool isopen = false;

            foreach (Form form in Application.OpenForms)
            {
                if (form.Text == "Form2")
                {
                    isopen = true;
                    form.Focus();
                    break;
                }
            }
            if (isopen == false)
            {
                Form2 f = new Form2();
                f.MdiParent = this;
                f.Show();
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void tileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void tileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileVertical);
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox1 f = new AboutBox1();
            f.ShowDialog();
        }
    }
}
