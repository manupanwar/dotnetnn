﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FirstWindowsFormApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //Adding Event to Button
            btnClick.Click += new EventHandler(ButtonClick);
        }

        private void ButtonClick(object sender, EventArgs e)
        {
            MessageBox.Show("Hello, User");
        }

        private void btnClickMe_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Date =" + DateTime.Now.ToLongDateString());
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Form is Closing");
        }
    }
}
