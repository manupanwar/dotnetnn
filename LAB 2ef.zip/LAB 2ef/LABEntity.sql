create table Album(
AlbumID integer PRIMARY KEY,
 Name varchar(20),
 Genre varchar(20),
 Year Date,
 Price integer);

 select * from Album;

 insert into Album values(101,'Rock On','Rock','2/02/2016',1245);

 insert into Album values(102,'One Direction','POP','2/12/2016',1245);

 insert into Album values(103,'KPOP','POP','2/12/2016',5745);

 insert into Album values(104,'Maroon5','POP','2/12/2016',784565);

