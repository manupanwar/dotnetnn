﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace CodeFirstDemo848808
{
  public  class ProductContext : DbContext
    {
        public DbSet<Product_848808> Products { get; set; }       
    }
}
