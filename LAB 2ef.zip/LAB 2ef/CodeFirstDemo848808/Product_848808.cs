﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Threading.Tasks;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CodeFirstDemo848808
{
  public  class Product_848808
    {
        [Key]
        public int ProductID { get; set; }
        public string ProductNAme { get; set; }
        public int Quantity { get; set; }
        public double UnitPrice { get; set; }
    }
}
