﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstDemo848808
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext pContext = new ProductContext();

            Product_848808 p1 = new Product_848808()
            {
                ProductID = 101,
                ProductNAme = "Notebook",
                Quantity = 10,
                UnitPrice = 100
            };

            Product_848808 p2 = new Product_848808()
           {
               ProductID = 102,
               ProductNAme = "Mobile",
               Quantity = 20,
               UnitPrice = 21500
           };

            pContext.Products.Add(p1);
            pContext.Products.Add(p2);

            pContext.SaveChanges();

            var query = from p in pContext.Products
                        select p;

            Console.WriteLine("Product details are");

            foreach (var p in query)
            {
             Console.WriteLine(p.ProductID+"\t"+p.ProductNAme+"\t"+p.Quantity+"\t"+p.UnitPrice);    
            }
            Console.ReadKey();
        }
    }
}
