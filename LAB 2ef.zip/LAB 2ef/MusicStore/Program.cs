﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MusicStore
{
    class Program
    {
        static void Main(string[] args)
        {
            Music_context mContext = new Music_context();

            var query = from m in mContext.Albums
                        select m;
            foreach (var m in query)
            {
                Console.WriteLine(m.AlbumID+"\t"+m.Name+"\t"+m.Genre+"\t"+m.Year+"\t"+m.Price);      
            }


            Album alb = new Album();
            {
                alb.AlbumID = 105;
                alb.Name = "Purpose";
                alb.Genre = "POP";

                mContext.Albums.Add(alb);
                mContext.SaveChanges();

                Console.WriteLine("Details Added Successfully!");
                Console.ReadKey();
            }

            Album alb1 = new Album();
            {
                alb1.AlbumID = 106;
                alb1.Name = "Purpose";
                alb1.Genre = "POP";
                alb1.Price = 54645;

                mContext.Albums.Add(alb1);
                mContext.SaveChanges();

                Console.WriteLine("Details Added Successfully!");
                Console.ReadKey();
            }
        }
    }
}