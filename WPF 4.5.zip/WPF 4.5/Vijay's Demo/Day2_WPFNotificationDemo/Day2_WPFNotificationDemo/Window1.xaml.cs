﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Day2_WPFNotificationDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        ObservableCollection<PersonalDetails> persons;

        public Window1()
        {
            InitializeComponent();

            persons = new ObservableCollection<PersonalDetails>() 
            {
                new PersonalDetails{FirstName="Vijay",LastName="Vishwakarma"},
                new PersonalDetails{FirstName="Ajay",LastName="Sharma"},
                new PersonalDetails{FirstName="Saba",LastName="Shaikh"},
                
            };

            lstNames.ItemsSource = persons;
        }

        private void btnNames_Click(object sender, RoutedEventArgs e)
        {
            persons.Add(new PersonalDetails()
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text
            });

            txtFirstName.Text = "";
            txtLastName.Text = "";
        }
    }
}
