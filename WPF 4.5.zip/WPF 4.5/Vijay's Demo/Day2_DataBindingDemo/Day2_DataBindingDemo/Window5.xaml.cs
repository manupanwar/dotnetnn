﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Day2_DataBindingDemo
{
    /// <summary>
    /// Interaction logic for Window5.xaml
    /// </summary>
    public partial class Window5 : Window
    {
        List<Product> prodList;
        public Window5()
        {
            InitializeComponent();

            prodList = new List<Product>()
            {
                new Product{ID=199,Name="Doll",Price=99.88,ImageURL=@"Images\doll.jpg"},
                new Product{ID=188,Name="Pen",Price=199.88,ImageURL=@"Images\pen.jpg"},
                new Product{ID=209,Name="Mouse",Price=299.88,ImageURL=@"Images\mouse.jpg"},
            };

            this.DataContext = prodList;
        }
    }
}
