﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Day2_DataBindingDemo
{
    /// <summary>
    /// Interaction logic for Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        public Window4()
        {
            InitializeComponent();

            List<Employee> empList = new List<Employee>()
            {
                new Employee{ID=1001,Name="Vijay",Designation="Consultant",Salary=998.88},
                new Employee{ID=1002,Name="Malcolm",Designation="Manager",Salary=889.11},
                new Employee{ID=1003,Name="Suresh",Designation="Manager",Salary=1098.88},
                new Employee{ID=1004,Name="Ajay",Designation="Sr Manager",Salary=778.88},
            };

            employeegrid.ItemsSource = empList;
        }
    }
}
