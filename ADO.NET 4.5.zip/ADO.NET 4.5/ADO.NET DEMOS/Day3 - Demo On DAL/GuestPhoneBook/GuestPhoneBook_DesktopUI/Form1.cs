﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using IGATEPATNI.GuestPhoneBook.Entities;
using IGATEPATNI.GuestPhoneBook.Exceptions;
using IGATEPATNI.GuestPhoneBook.BL;

namespace GuestPhoneBook_DesktopUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        protected void FillGrid()
        {
            List<Guest> guestList = GuestBL.GetAllGuestsBL();

            dgvGuest.DataSource = guestList;
        }

        protected void ClearFields()
        {
            txtID.Text = string.Empty;
            txtName.Text = string.Empty;
            txtContact.Text = string.Empty;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FillGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guest = new Guest();
                guest.GuestID = Convert.ToInt32(txtID.Text);
                guest.GuestName = txtName.Text;
                guest.GuestContactNumber = txtContact.Text;

                bool status = GuestBL.AddGuestBL(guest);

                if (status)
                {
                    MessageBox.Show("Guest Added");
                    FillGrid();
                    ClearFields();
                }
                else
                    MessageBox.Show("Unable to Add Guest");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtID.Text);

                Guest guest = GuestBL.SearchGuestBL(id);

                if (guest == null)
                {
                    MessageBox.Show("Guest Not Available");
                }
                else
                {
                    txtName.Text = guest.GuestName;
                    txtContact.Text = guest.GuestContactNumber;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Guest guest = new Guest();
                guest.GuestID = Convert.ToInt32(txtID.Text);
                guest.GuestName = txtName.Text;
                guest.GuestContactNumber = txtContact.Text;

                bool status = GuestBL.UpdateGuestBL(guest);

                if (status)
                {
                    MessageBox.Show("Guest Updated");
                    FillGrid();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to updated Guest");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtID.Text);

                bool status = GuestBL.DeleteGuestBL(id);

                if (status)
                {
                    MessageBox.Show("Guest Deleted");
                    FillGrid();
                    ClearFields();
                }
                else
                {
                    MessageBox.Show("Unable to Delete Guest");
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
