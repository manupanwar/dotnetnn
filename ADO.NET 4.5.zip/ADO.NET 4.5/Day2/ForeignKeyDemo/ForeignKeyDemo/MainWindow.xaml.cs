﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace ForeignKeyDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        DataTable dtProd;
        DataTable dtCategory;

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dtCategory = new DataTable();
            dtCategory.Columns.Add("CategoryID");
            dtCategory.Columns.Add("CategoryName");
            dtCategory.PrimaryKey = new DataColumn[] { dtCategory.Columns["CategoryID"] };

            DataRow dr = dtCategory.NewRow();
            dr["CategoryID"] = 10;
            dr["CategoryName"] = "Stationary";
            dtCategory.Rows.Add(dr);

            DataRow dr1 = dtCategory.NewRow();
            dr1["CategoryID"] = 20;
            dr1["CategoryName"] = "Toys";
            dtCategory.Rows.Add(dr1);

            DataRow dr2 = dtCategory.NewRow();
            dr2["CategoryID"] = 30;
            dr2["CategoryName"] = "Colors";
            dtCategory.Rows.Add(dr2);

            dtProd = new DataTable();
            dtProd.Columns.Add("ProductID");
            dtProd.Columns.Add("ProductName");
            dtProd.Columns.Add("Price");
            dtProd.Columns.Add("Quantity");
            dtProd.Columns.Add("CategoryID");

            dtProd.PrimaryKey = new DataColumn[] { dtProd.Columns["ProductID"] };

            ForeignKeyConstraint catProdFK = new ForeignKeyConstraint("CatProdFK", dtCategory.Columns["CategoryID"], dtProd.Columns["CategoryID"]);
            dtProd.Constraints.Add(catProdFK);

            dgProduct.DataContext = dtProd;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = dtProd.NewRow();

            row["ProductID"] = txtProductID.Text;
            row["ProductName"] = txtProductName.Text;
            row["Price"] = txtProductPrice.Text;
            row["Quantity"] = txtProductQuantity.Text;
            row["CategoryID"] = txtCategoryID.Text;

            dtProd.Rows.Add(row);
        }
    }
}
