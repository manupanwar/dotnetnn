﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;

namespace DataTableDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DataTable dt;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            dt = new DataTable("Product");
            
            DataColumn dcID = new DataColumn();
            dcID.ColumnName = "ProductID";
            dcID.DataType = typeof(int);
            dt.Columns.Add(dcID);

            DataColumn dcName = new DataColumn("ProductName", typeof(string));
            dt.Columns.Add(dcName);

            dt.Columns.Add(new DataColumn("Price", typeof(decimal)));

            dt.Columns.Add("Quantity", typeof(int));

            dt.PrimaryKey = new DataColumn[]{dcID};

            dgProduct.DataContext = dt;
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = dt.NewRow();
            row["ProductID"] = txtProductID.Text;
            row["ProductName"] = txtProductName.Text;
            row["Price"] = txtProductPrice.Text;
            row["Quantity"] = txtProductQuantity.Text;
            dt.Rows.Add(row);
        }
    }
}
