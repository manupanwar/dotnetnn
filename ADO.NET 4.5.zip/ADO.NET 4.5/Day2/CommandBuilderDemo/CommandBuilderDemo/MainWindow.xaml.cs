﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CommandBuilderDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;

        public MainWindow()
        {
            InitializeComponent();

            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            da = new SqlDataAdapter("SELECT * FROM Student_Master", con);
            da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            SqlCommandBuilder cmd = new SqlCommandBuilder(da);
            ds = new DataSet();
            da.Fill(ds, "stud");

            dgStudent.DataContext = ds.Tables["stud"];
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = ds.Tables["stud"].Rows.Find(txtStudCode.Text);

            if (row != null)
            {
                Student stud = new Student();
                stud.StudCode = (int)row["Student_Code"];
                stud.StudName = row["Student_name"].ToString();
                stud.DeptCode = (int)row["Dept_Code"];
                stud.DOB = Convert.ToDateTime(row["Student_dob"]);
                stud.Address = row["Student_Address"].ToString();

                gridStudent.DataContext = stud;
                txtStudCode.IsReadOnly = true;
                txtStudName.IsReadOnly = true;
                txtStudDob.IsEnabled = false;
                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Record Not Found");
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = ds.Tables["stud"].NewRow();

            row["Student_Code"] = txtStudCode.Text;
            row["Student_name"] = txtStudName.Text;
            row["Dept_Code"] = txtDeptCode.Text;
            row["Student_dob"] = Convert.ToDateTime(txtStudDob.Text);
            row["Student_Address"] = txtStudAddress.Text;

            ds.Tables["stud"].Rows.Add(row);

            int recordsAffected = da.Update(ds, "stud");

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record Added Successfully");
                Clear();
            }
            else
                MessageBox.Show("Record not added");
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtStudDob.Text = "";
            txtStudAddress.Text = "";
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtStudCode.IsReadOnly = false;
            txtStudName.IsReadOnly = false;
            txtStudDob.IsEnabled = true;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < ds.Tables["stud"].Rows.Count; i++)
            {
                if (ds.Tables["stud"].Rows[i]["Student_Code"].ToString() == txtStudCode.Text)
                {
                    ds.Tables["stud"].Rows[i]["Dept_Code"] = txtDeptCode.Text;
                    ds.Tables["stud"].Rows[i]["Student_Address"] = txtStudAddress.Text;
                }
            }

            int recordsAffected = da.Update(ds, "stud");
            if (recordsAffected > 0)
            {
                MessageBox.Show("Record Updated Successfully");
                Clear();
            }
            else
                MessageBox.Show("Record not updated");
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DataRow row = ds.Tables["stud"].Rows.Find(txtStudCode.Text);

            if (row != null)
            {
                ds.Tables["stud"].Rows.Remove(row);

                int recordsAffected = da.Update(ds, "stud");

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record deleted successfully");
                    Clear();
                }
                else
                    MessageBox.Show("Record not deleted");
            }
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
