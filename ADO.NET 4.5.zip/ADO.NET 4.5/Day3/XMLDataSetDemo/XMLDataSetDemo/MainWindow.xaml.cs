﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;
using System.IO;
using System.Data;
using System.Data.SqlClient;

namespace XMLDataSetDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnRead_Click(object sender, RoutedEventArgs e)
        {
            FileStream fs = new FileStream(@"..\..\products.xml", FileMode.Open, FileAccess.Read);
            DataSet ds = new DataSet();
            ds.ReadXml(fs);
            fs.Close();
            dgXml.DataContext = ds.Tables[0];
        }

        private void btnWrite_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_19Jul17_Pune;uid=sqluser;pwd=sqluser");
            SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Student_Master", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "stud");

            FileStream fs = new FileStream("stud.xml", FileMode.Create, FileAccess.Write);
            ds.WriteXml(fs);
            fs.Close();
            MessageBox.Show("Data Written to XML");
        }
    }
}
