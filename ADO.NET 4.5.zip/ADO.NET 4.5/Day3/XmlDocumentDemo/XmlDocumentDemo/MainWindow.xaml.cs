﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;


namespace XmlDocumentDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public XmlDocument LoadXml()
        {
            XmlDocument prodDoc = new XmlDocument();
            prodDoc.Load(@"..\..\products.xml");
            return prodDoc;
        }

        private void btnProduct_Click(object sender, RoutedEventArgs e)
        {
            XmlDocument prodDoc = LoadXml();

            XmlNodeList prodList = prodDoc.GetElementsByTagName("ProductID");

            MessageBox.Show("Number of Products : " + prodList.Count);
        }

        private void btnQuantity_Click(object sender, RoutedEventArgs e)
        {
            XmlDocument prodDoc = LoadXml();

            int totalProd = 0;
            int quantity = 0;

            XmlNodeList prodList = prodDoc.GetElementsByTagName("ProductID");

            foreach (XmlNode prod in prodList)
            {
                XmlAttributeCollection attrColl = prod.Attributes;

                int qty = XmlConvert.ToInt32(attrColl.GetNamedItem("quantity").Value);
                totalProd += 1;
                quantity = quantity + qty;
            }

            MessageBox.Show("Total Number of Products : " + totalProd + " & quantity ordered is : " + quantity);
        }
    }
}
