﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security;

namespace SqlCredentialDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        SecureString securePwd = new SecureString();
        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            securePwd.MakeReadOnly();
            SqlCredential cre = new SqlCredential(txtUserID.Text, securePwd);

            con.Credential = cre;

            SqlCommand cmd = new SqlCommand("SELECT * FROM Student_master", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            con.Close();

            dgStudent.DataContext = dt;
        }

        private void txtPassword_KeyUp(object sender, KeyEventArgs e)
        {
            securePwd.AppendChar(Convert.ToChar(e.Key.ToString().ToLower()));
        }
    }
}
