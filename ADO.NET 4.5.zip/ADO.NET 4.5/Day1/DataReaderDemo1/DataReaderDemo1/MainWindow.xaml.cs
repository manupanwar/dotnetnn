﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace DataReaderDemo1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Database=Training_19Jul17_Pune;uid=sqluser;pwd=sqluser;";

            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "SELECT * FROM Student_master";
            cmd.Connection = con;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    int stud_code = (int)dr["Student_Code"];
                    string name = dr["Student_name"].ToString();
                    int dept_code = (int)dr["Dept_Code"];
                    DateTime dob = Convert.ToDateTime(dr["Student_dob"]);
                    string add = dr["Student_Address"].ToString();

                    MessageBox.Show(stud_code + " " + name + " " + dept_code + " " + dob + " " + add);
                }

            }
            else
            {
                MessageBox.Show("Data Reader is empty");
            }

            con.Close();
        }
    }
}
