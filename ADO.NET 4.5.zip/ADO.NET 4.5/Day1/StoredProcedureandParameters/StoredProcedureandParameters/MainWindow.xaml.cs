﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace StoredProcedureandParameters
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con = new SqlConnection();
        SqlCommand cmd;
        SqlDataReader dr;

        public MainWindow()
        {
            InitializeComponent();

            con.ConnectionString = ConfigurationManager.ConnectionStrings["Training"].ConnectionString;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        public void Show()
        {
            cmd = new SqlCommand("usp_DisplayStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;

            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                DataTable dt = new DataTable();
                dt.Load(dr);
                dgStudent.DataContext = dt;
            }
            else
            {
                MessageBox.Show("Student Records Not Available");
            }

            con.Close();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_InsertStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter scode = new SqlParameter();
            scode.ParameterName = "@Stud_Code";
            scode.SqlDbType = SqlDbType.Int;
            scode.Direction = ParameterDirection.Input;
            scode.Value = txtStudCode.Text;
            cmd.Parameters.Add(scode);

            SqlParameter sname = new SqlParameter();
            sname.ParameterName = "@Stud_Name";
            sname.SqlDbType = SqlDbType.VarChar;
            sname.Size = 30;
            sname.Direction = ParameterDirection.Input;
            sname.Value = txtStudName.Text;
            cmd.Parameters.Add(sname);

            SqlParameter dcode = new SqlParameter();
            dcode.ParameterName = "@Dept_Code";
            dcode.SqlDbType = SqlDbType.Int;
            dcode.Direction = ParameterDirection.Input;
            dcode.Value = txtDeptCode.Text;
            cmd.Parameters.Add(dcode);

            SqlParameter dob = new SqlParameter();
            dob.ParameterName = "@DOB";
            dob.SqlDbType = SqlDbType.Date;
            dob.Direction = ParameterDirection.Input;
            dob.Value = Convert.ToDateTime(txtStudDob.Text);
            cmd.Parameters.Add(dob);

            SqlParameter address = new SqlParameter();
            address.ParameterName = "@Address";
            address.SqlDbType = SqlDbType.VarChar;
            address.Size = 50;
            address.Direction = ParameterDirection.Input;
            address.Value = txtStudAddress.Text;
            cmd.Parameters.Add(address);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record added successfully");
                Clear();
                Show();
            }
            else
            {
                MessageBox.Show("Record not added");
            }
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtStudDob.Text = "";
            txtStudAddress.Text = "";
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtStudCode.IsReadOnly = false;
            txtStudName.IsReadOnly = false;
            txtStudDob.IsEnabled = true;
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_SearchStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@Stud_Code", txtStudCode.Text));

            con.Open();
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                Student stud = new Student();
                stud.StudCode = (int)dr["Student_Code"];
                stud.StudName = dr["Student_name"].ToString();
                stud.DeptCode = (int)dr["Dept_Code"];
                stud.DOB = Convert.ToDateTime(dr["Student_dob"]);
                stud.Address = dr["Student_Address"].ToString();

                gridStudent.DataContext = stud;

                btnUpdate.IsEnabled = true;
                btnDelete.IsEnabled = true;
                txtStudCode.IsReadOnly = true;
                txtStudName.IsReadOnly = true;
                txtStudDob.IsEnabled = false;
            }
            else
            {
                MessageBox.Show("Record not found");
            }
            con.Close();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_UpdateStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Stud_Code", txtStudCode.Text);
            cmd.Parameters.AddWithValue("@Dept_Code", txtDeptCode.Text);
            cmd.Parameters.AddWithValue("@Address", txtStudAddress.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record updated Successfully");
                Show();
                Clear();
            }
            else
            {
                MessageBox.Show("Record not updated");
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("usp_DeleteStudent", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Stud_Code", txtStudCode.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                MessageBox.Show("Record deleted successfully");
                Show();
                Clear();
            }
            else
            {
                MessageBox.Show("Record not deleted");
            }
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM Student_master", con);

            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();

            MessageBox.Show("Number of Students : " + count);
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
