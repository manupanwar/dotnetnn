﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace DataReaderDemo2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Database=Training_19Jul17_Pune;uid=sqluser;pwd=sqluser");
            SqlCommand cmd = new SqlCommand("SELECT * FROM Student_Master", con);

            List<Student> studList = null;

            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                studList = new List<Student>();

                while (dr.Read())
                {
                    Student stud = new Student();

                    stud.Stud_Code = (int)dr["Student_Code"];
                    stud.Name = dr["Student_name"].ToString();
                    stud.Dept_Code = (int)dr["Dept_Code"];
                    stud.DOB = Convert.ToDateTime(dr["Student_dob"]);
                    stud.Address = dr["Student_Address"].ToString();

                    studList.Add(stud);
                }

                dgStudent.DataContext = studList;
            }
            else
            {
                MessageBox.Show("No Data");
            }

            con.Close();
        }
    }


    public class Student
    {
        public int Stud_Code { get; set; }
        public string Name { get; set; }
        public int Dept_Code { get; set; }
        public DateTime DOB { get; set; }
        public string Address { get; set; }
    }
}
