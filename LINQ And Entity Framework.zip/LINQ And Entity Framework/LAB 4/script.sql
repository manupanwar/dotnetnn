create table Employee_Details
(
	ID int primary key,
	Name varchar(20),
	DOB Datetime,
	DOJ Datetime,
	Designation varchar(20),
	Salary decimal
);

drop table Employee_Details

select * from Employee_Details