﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQEFConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_8thAug2016_PuneEntities context = new Training_8thAug2016_PuneEntities();

            var query = from staff in context.Staff_Master
                        select staff;

            foreach (Staff_Master s in query)
            {
                Console.WriteLine(s.Staff_Code + "" + s.Staff_Name + "" + s.Hiredate);
            }


            var query1 = from staff1 in context.Staff_Master
                         where staff1.Salary > 30000
                         select staff1;

            foreach (Staff_Master s in query1)
            {
                Console.WriteLine(s.Staff_Code + "" + s.Staff_Name + "" + s.Salary);
            }

            var query2 = from std in context.Student_master
                         where std.Address != null
                         select std;

            foreach (Student_master s in query2)
            {
                Console.WriteLine(s.Stud_Name + "" + s.Stud_Code);
            }

            var query3 = from stud in context.Student_master
                         select stud;

            foreach (Student_master s in query3)
            {
                Console.WriteLine(s.Stud_Name + "" + s.Stud_Code + "" + s.Stud_Dob);
            }

            var query4 = from stud in context.Student_master
                         where stud.Address == "Bangalore"
                         group stud by stud.Address into g
                         select new
                         {
                             address = g.Key,
                             NoofStudent = g.Count()
                         };

            Console.WriteLine("Total no of students from bangalore");

            foreach (var s in query4)
            {
                Console.WriteLine(s.address + "" + s.NoofStudent);
            }
                                            
            Student_master student = new Student_master
            {
                Stud_Code = 101,
                Stud_Name = "Ram",
                Stud_Dob = Convert.ToDateTime("2/02/2016")
            };
            context.Student_master.Add(student);
            context.SaveChanges();
            Console.WriteLine("Student Data Saved!");


            Student_master upStud = (from s in context.Student_master.Where
                                     (s => s.Stud_Code == 101)
                                     select s).FirstOrDefault();

            if (upStud != null)
            {

                upStud.Address = "Chennai";
                context.SaveChanges();
                Console.WriteLine("Student Data Updated");
            }
            else
            {
                Console.WriteLine("Data not updated");
            }

            Student_master delStud = (from s in context.Student_master.Where
                                     (s => s.Stud_Code == 101)
                                     select s).FirstOrDefault();
            if (delStud != null)
            {
                context.Student_master.Remove(delStud);
                context.SaveChanges();
                Console.WriteLine("Student Deleted Successfully");
            }
            else
            {
                Console.WriteLine("Student Not Deleted");
            }
   }

       
        


   }
}
