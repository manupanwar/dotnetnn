﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQlab4
{
    class Program
    {
        static void Main(string[] args)
        {
            TrainingEntities tcontext = new TrainingEntities();

            //Adding an Employee Details
            Employee_Details emp = new Employee_Details
            {
                ID = 101,
                Name = "Aiden",
                DOB = Convert.ToDateTime("08/08/1994"),
                DOJ = Convert.ToDateTime("09/12/2016"),
                Designation = "Admin",
                Salary = 50000
            };

            Employee_Details emp1 = new Employee_Details
            {
                ID = 102,
                Name = "Evelyn",
                DOB = Convert.ToDateTime("06/15/1992"),
                DOJ = Convert.ToDateTime("07/04/2014"),
                Designation = "Developer",
                Salary = 50000
            };

            tcontext.Employee_Details.Add(emp);
            tcontext.Employee_Details.Add(emp1);

            tcontext.SaveChanges();
            Console.WriteLine("Employee Details Saved Successfully");

            //Updating Employee Details
            Employee_Details empUpdate = (from e in tcontext.Employee_Details.Where
                                              (e => e.ID == 102)
                                          select e).FirstOrDefault();

            if (empUpdate != null)
            {
                empUpdate.Salary = 55000;
                tcontext.SaveChanges();
                Console.WriteLine("Employee Details Updated Successfully");
            }
            else
            {
                Console.WriteLine("Cannot Update Employee Details\nEmployee not available");
            }

            //Searching for Details of an Employee
            var query = from e in tcontext.Employee_Details
                        where e.ID == 102
                        select e;

            foreach (Employee_Details em in query)
            {
                Console.WriteLine("Employee ID:" +em.ID+"\nName:"+em.Name+"\nDate of Birth:"+ em.DOB+"\nDate of Joining:"+em.DOJ+"\nDesignation:"+em.Designation+"\nSalary:"+em.Salary);
            }

            //Deleting Employee Details
            Employee_Details empDelete = (from e in tcontext.Employee_Details.Where
                                              (e => e.ID == 102)
                                          select e).FirstOrDefault();

            if (empDelete != null)
            {
                tcontext.Employee_Details.Remove(empDelete);
                tcontext.SaveChanges();
                Console.WriteLine("Employee Details Deleted Successfully");
            }
            else
            {
                Console.WriteLine("Cannot Delete Employee Details\nEmployee not available");
            }
        }
    }
}
